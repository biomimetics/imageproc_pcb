README File for MotorDriver-1-multiple

The following gerber files are RS274X:
MotorDriver-1-multiple.GTL - Top copper layer gerber file
MotorDriver-1-multiple.GTS - Top soldermask gerber file
MotorDriver-1-multiple.GBL - Bottom copper layer gerber file
MotorDriver-1-multiple.GBS - Bottom soldermask gerber file
MotorDriver-1-multiple.GKO - Keep-Out layer gerber file
MotorDriver-1-multiple.GDD - Gerber drill drawing
MotorDriver-1-multiple.GDG - Gerber drill guide


MotorDriver-1-multiple.MAT - Aperture file
MotorDriver-1-multiple.TOL - NcDrill Tool Loading Specification
MotorDriver-1-multiple.DRL - N/C binary drill file
MotorDriver-1-multiple.TXT - ASCII drill file (?)

Fernando Garcia Bermudez
fgb@eecs.berkeley.edu