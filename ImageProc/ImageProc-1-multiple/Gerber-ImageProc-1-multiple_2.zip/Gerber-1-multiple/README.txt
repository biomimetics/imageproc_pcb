README File for ImageProc-1-multiple

The following gerber files are RS274X:
ImageProc-1-multiple.GTL - Top copper layer gerber file
ImageProc-1-multiple.GTS - Top soldermask gerber file
ImageProc-1-multiple.GBL - Bottom copper layer gerber file
ImageProc-1-multiple.GBS - Bottom soldermask gerber file
ImageProc-1-multiple.GKO - Keep-Out layer gerber file
ImageProc-1-multiple.GDD - Gerber drill drawing
ImageProc-1-multiple.GDG - Gerber drill guide


ImageProc-1-multiple.MAT - Aperture file
ImageProc-1-multiple.TOL - NcDrill Tool Loading Specification
ImageProc-1-multiple.DRL - N/C binary drill file
ImageProc-1-multiple.TXT - ASCII drill file (?)

Fernando Garcia Bermudez
fgb@eecs.berkeley.edu